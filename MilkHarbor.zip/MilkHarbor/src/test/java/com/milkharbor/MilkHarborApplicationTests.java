package com.milkharbor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MilkHarborApplicationTests {

	@Test
	void contextLoads() {
	}

}
