package com.milkharbor.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.milkharbor.entity.Farmer;
import com.milkharbor.service.FarmerService;


@RestController
@RequestMapping("/farmer")
public class FarmerController {
	
	@Autowired
	FarmerService farmerService;
	
	@PostMapping("/registerAdmin")
	public Farmer register(@RequestBody Farmer farmer)throws Exception {
		return farmerService.register(farmer);
	}
	
	public Object login(@PathVariable String username,@PathVariable String password)throws Exception {
		return farmerService.login(password, password);
	}

}
