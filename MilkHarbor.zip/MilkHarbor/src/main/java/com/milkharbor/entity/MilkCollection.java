package com.milkharbor.entity;

public class MilkCollection {

}
