package com.milkharbor.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Farmer {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int f_id;
	private String f_name;
	private String f_email;
	private String f_m_no;
	private String f_password;
	private String role;
	private String status;
	private String f_isActive;
	
	public int getF_id() {
		return f_id;
	}
	public void setF_id(int f_id) {
		this.f_id = f_id;
	}
	public String getF_name() {
		return f_name;
	}
	public void setF_name(String f_name) {
		this.f_name = f_name;
	}
	public String getF_email() {
		return f_email;
	}
	public void setF_email(String f_email) {
		this.f_email = f_email;
	}
	public String getF_m_no() {
		return f_m_no;
	}
	public void setF_m_no(String f_m_no) {
		this.f_m_no = f_m_no;
	}
	public String getF_password() {
		return f_password;
	}
	public void setF_password(String f_password) {
		this.f_password = f_password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getF_isActive() {
		return f_isActive;
	}
	public void setF_isActive(String f_isActive) {
		this.f_isActive = f_isActive;
	}
	
		
}
