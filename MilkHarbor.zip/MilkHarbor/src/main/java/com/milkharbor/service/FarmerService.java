package com.milkharbor.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.milkharbor.dao.FarmerDao;
import com.milkharbor.entity.Farmer;

@Service
public class FarmerService {

	@Autowired
	FarmerDao farmerDao;
	
	public Farmer register(Farmer farmer)throws Exception {
		return farmerDao.register(farmer);
	}
	
	public Object login(String username, String password)throws Exception {
		return farmerDao.login(password, password);
	}
}
