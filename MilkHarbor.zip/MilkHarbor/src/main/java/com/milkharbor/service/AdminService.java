package com.milkharbor.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.milkharbor.dao.AdminDao;
import com.milkharbor.entity.Admin;

@Service
public class AdminService {


	@Autowired
	AdminDao adminDao;
	
	public Admin register(Admin admin) {
		return adminDao.register(admin);
	}
}
