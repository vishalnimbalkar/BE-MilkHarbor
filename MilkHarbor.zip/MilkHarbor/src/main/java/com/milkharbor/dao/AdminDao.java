package com.milkharbor.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.milkharbor.entity.Admin;

@Repository
public class AdminDao {
	

	@Autowired
	SessionFactory sf;
	
	public Admin register(Admin admin) {
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
	    s.save(admin);
		tr.commit();
		s.close();
		return admin;
	}
}
