package com.milkharbor.dao;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.milkharbor.encryption.PasswordEncryption;
import com.milkharbor.entity.Farmer;
import com.milkharbor.entity.ResponseLogin;

@Repository
public class FarmerDao {

	@Autowired
	SessionFactory sf;
	PasswordEncryption ed;
	
	public Farmer register(Farmer farmer) throws Exception {
		ed.encrypt(farmer.getF_password());
		Session s=sf.openSession();
		Transaction tr=s.beginTransaction();
	    s.save(farmer);
		tr.commit();
		s.close();
		return farmer;
	}
	
	public Object login(String username, String password) throws Exception {
		 Session s = sf.openSession();
		    Criteria cr = s.createCriteria(Farmer.class);
		    cr.add(Restrictions.eq("f_email", username));
		    cr.setMaxResults(1);
		    Farmer farmer = (Farmer) cr.uniqueResult();

		    if (farmer != null && password.equals(ed.decrypt(farmer.getF_password()))) {
		        ResponseLogin responseLogin = new ResponseLogin();
		        responseLogin.setId(farmer.getF_id());
		        responseLogin.setName(farmer.getF_name());
		        responseLogin.setEmail(farmer.getF_email());
		        responseLogin.setM_no(farmer.getF_m_no());
		        responseLogin.setRole(farmer.getRole());
		        responseLogin.setIsActive(farmer.getF_isActive());
		        responseLogin.setStatus(farmer.getStatus());
		        s.close();
		        return responseLogin; // Authentication successful
		    } else {
		        s.close();
		        return "Invalid email or password"; // Custom error message
		    }
	}
}
