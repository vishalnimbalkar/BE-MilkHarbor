package com.milkharbor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MilkHarborApplication {

	public static void main(String[] args) {
		SpringApplication.run(MilkHarborApplication.class, args);
	}

}
